// Cloudflare Worker that proxies chat requests from the Android app to the AI provider.
// The provider API key lives only here, as a Worker secret. It is never shipped in the app.

const MAX_MESSAGES = 20;
const MAX_CONTENT = 4000;
const MAX_SYSTEM = 8000;

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function constantTimeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function sanitizeMessages(input) {
  if (!Array.isArray(input) || input.length === 0) return null;
  const messages = input
    .slice(-MAX_MESSAGES)
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_CONTENT) }));
  if (messages.length === 0 || messages[0].role !== "user") return null;
  return messages;
}

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);

    const expected = `Bearer ${env.APP_TOKEN || ""}`;
    const provided = request.headers.get("Authorization") || "";
    if (!env.APP_TOKEN || !constantTimeEqual(provided, expected)) {
      return json({ error: "unauthorized" }, 401);
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "bad_request" }, 400);
    }

    const messages = sanitizeMessages(body.messages);
    if (!messages) return json({ error: "bad_request" }, 400);
    const system = typeof body.system === "string" ? body.system.slice(0, MAX_SYSTEM) : undefined;

    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: env.MODEL || "claude-sonnet-5-5",
        max_tokens: 600,
        system,
        messages,
      }),
    });

    if (!upstream.ok) return json({ error: "upstream_error", status: upstream.status }, 502);

    const data = await upstream.json();
    const reply = (data.content || [])
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n");
    return json({ reply });
  },
};
