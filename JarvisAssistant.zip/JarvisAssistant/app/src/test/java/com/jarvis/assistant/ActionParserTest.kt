package com.jarvis.assistant

import com.jarvis.assistant.domain.ActionParser
import com.jarvis.assistant.domain.PhoneAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ActionParserTest {

    @Test fun replyWithoutTag() {
        val parsed = ActionParser.parse("ঠিক আছে।")
        assertEquals("ঠিক আছে।", parsed.spokenText)
        assertNull(parsed.action)
    }

    @Test fun flashlightTagIsExtractedAndStripped() {
        val parsed = ActionParser.parse("""চালু করছি। <action>{"type":"flashlight","on":true}</action>""")
        assertEquals("চালু করছি।", parsed.spokenText)
        assertEquals(PhoneAction.Flashlight(true), parsed.action)
    }

    @Test fun alarmTag() {
        val parsed = ActionParser.parse("""<action>{"type":"alarm","hour":6,"minute":15}</action>""")
        assertEquals(PhoneAction.Alarm(6, 15), parsed.action)
    }

    @Test fun invalidAlarmIsRejected() {
        val parsed = ActionParser.parse("""<action>{"type":"alarm","hour":99}</action>""")
        assertNull(parsed.action)
    }

    @Test fun malformedJsonIsIgnored() {
        val parsed = ActionParser.parse("ঠিক আছে <action>{oops</action>")
        assertEquals("ঠিক আছে", parsed.spokenText)
        assertNull(parsed.action)
    }

    @Test fun unknownTypeIsIgnored() {
        assertNull(ActionParser.parse("""<action>{"type":"format_phone"}</action>""").action)
    }

    @Test fun remindTag() {
        val parsed = ActionParser.parse("""<action>{"type":"remind","text":"ওষুধ","minutes":30}</action>""")
        assertEquals(PhoneAction.Remind("ওষুধ", 30), parsed.action)
    }
}
