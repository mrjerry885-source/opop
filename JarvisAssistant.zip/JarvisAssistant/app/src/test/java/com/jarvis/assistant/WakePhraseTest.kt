package com.jarvis.assistant

import com.jarvis.assistant.voice.WakePhrase
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakePhraseTest {
    @Test fun exactPhrase() = assertTrue(WakePhrase.matches("Hey Jarvis"))
    @Test fun phraseInsideSentence() = assertTrue(WakePhrase.matches("okay hey jarvis what time is it"))
    @Test fun bengaliSpelling() = assertTrue(WakePhrase.matches("হেই জার্ভিস"))
    @Test fun unrelatedSpeech() = assertFalse(WakePhrase.matches("hello there how are you"))
}
