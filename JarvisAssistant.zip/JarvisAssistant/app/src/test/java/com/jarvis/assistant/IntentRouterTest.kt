package com.jarvis.assistant

import com.jarvis.assistant.domain.IntentRouter
import com.jarvis.assistant.domain.PhoneAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IntentRouterTest {

    @Test fun flashlightOnBengali() =
        assertEquals(PhoneAction.Flashlight(true), IntentRouter.route("ফ্ল্যাশলাইট জ্বালাও"))

    @Test fun flashlightOffBengali() =
        assertEquals(PhoneAction.Flashlight(false), IntentRouter.route("টর্চ বন্ধ করো"))

    @Test fun flashlightOnEnglish() =
        assertEquals(PhoneAction.Flashlight(true), IntentRouter.route("turn the flashlight on"))

    @Test fun alarmMorningBengaliDigits() =
        assertEquals(PhoneAction.Alarm(7, 0), IntentRouter.route("সকাল ৭টায় অ্যালার্ম সেট করো"))

    @Test fun alarmAfternoonWithMinutes() =
        assertEquals(PhoneAction.Alarm(17, 30), IntentRouter.route("বিকাল ৫:৩০ এ অ্যালার্ম দাও"))

    @Test fun alarmRejectsInvalidHour() =
        assertNull(IntentRouter.route("alarm at 45"))

    @Test fun timerMinutes() =
        assertEquals(PhoneAction.Timer(300), IntentRouter.route("৫ মিনিটের টাইমার দাও"))

    @Test fun timerWithoutDurationFallsThrough() =
        assertNull(IntentRouter.route("একটা টাইমার দাও"))

    @Test fun remindInMinutes() {
        val action = IntentRouter.route("১০ মিনিট পরে মনে করিয়ে দাও চা খেতে")
        assertTrue(action is PhoneAction.Remind)
        assertEquals(10, (action as PhoneAction.Remind).minutes)
    }

    @Test fun rememberNote() {
        val action = IntentRouter.route("মনে রাখো আমার জন্মদিন ১০ মার্চ")
        assertTrue(action is PhoneAction.Remember)
        assertTrue((action as PhoneAction.Remember).text.contains("10"))
    }

    @Test fun dialNumber() =
        assertEquals(PhoneAction.Dial("01712345678"), IntentRouter.route("01712345678 নম্বরে কল করো"))

    @Test fun openAppBengaliAlias() =
        assertEquals(PhoneAction.OpenApp("youtube"), IntentRouter.route("ইউটিউব খোলো"))

    @Test fun openAppEnglish() =
        assertEquals(PhoneAction.OpenApp("calculator"), IntentRouter.route("open calculator"))

    @Test fun notificationSummary() =
        assertEquals(PhoneAction.SummarizeNotifications, IntentRouter.route("নোটিফিকেশনের সারাংশ বলো"))

    @Test fun unknownGoesToAi() =
        assertNull(IntentRouter.route("আজকের আবহাওয়া কেমন হবে?"))

    @Test fun blankIsIgnored() = assertNull(IntentRouter.route("   "))
}
