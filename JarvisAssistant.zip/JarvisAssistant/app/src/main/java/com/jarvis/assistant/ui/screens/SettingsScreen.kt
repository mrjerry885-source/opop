package com.jarvis.assistant.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.R
import com.jarvis.assistant.ui.MainViewModel
import com.jarvis.assistant.ui.Permissions
import com.jarvis.assistant.ui.rememberResumeTick

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val resumeTick = rememberResumeTick()

    var url by remember { mutableStateOf(settings.backendUrl) }
    var token by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<Int?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var micRationaleFor by remember { mutableStateOf<String?>(null) } // "wake" or "mic"
    var rationale by remember { mutableStateOf<Rationale?>(null) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && micRationaleFor == "wake") viewModel.setWakeWord(true)
        micRationaleFor = null
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    rationale?.let { r ->
        RationaleDialog(
            title = stringResource(r.title),
            message = stringResource(r.message),
            onConfirm = {
                rationale = null
                r.onConfirm()
            },
            onDismiss = { rationale = null }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_all)) },
            text = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    viewModel.deleteAllData()
                }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SectionTitle(R.string.settings_backend)
        OutlinedTextField(
            value = url,
            onValueChange = { url = it; message = null },
            label = { Text(stringResource(R.string.backend_url)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        OutlinedTextField(
            value = token,
            onValueChange = { token = it; message = null },
            label = { Text(stringResource(R.string.backend_token)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            placeholder = { if (viewModel.hasToken()) Text("••••••••") }
        )
        Text(stringResource(R.string.backend_hint), style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            if (url.isNotBlank() && !url.trim().startsWith("https://")) {
                message = R.string.err_https_required
            } else {
                viewModel.saveBackend(url, token)
                token = ""
                message = R.string.saved
            }
        }) { Text(stringResource(R.string.save)) }
        message?.let { Text(stringResource(it), color = MaterialTheme.colorScheme.primary) }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SectionTitle(R.string.settings_wake)
        SwitchRow(
            title = stringResource(R.string.settings_wake),
            description = stringResource(R.string.wake_desc),
            checked = settings.wakeWord,
            onCheckedChange = { enable ->
                if (!enable) viewModel.setWakeWord(false)
                else if (Permissions.hasMic(context)) viewModel.setWakeWord(true)
                else rationale = Rationale(R.string.perm_mic_title, R.string.perm_mic_why) {
                    micRationaleFor = "wake"
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SectionTitle(R.string.settings_privacy)
        SwitchRow(stringResource(R.string.privacy_memory), null, settings.memoryEnabled, viewModel::setMemory)
        SwitchRow(stringResource(R.string.privacy_log), null, settings.logConversations && settings.memoryEnabled, viewModel::setLogConversations)
        SwitchRow(stringResource(R.string.privacy_collect_notif), null, settings.collectNotifications, viewModel::setCollectNotifications)
        SwitchRow(stringResource(R.string.privacy_share_notif), null, settings.shareNotificationsWithAi, viewModel::setShareNotifications)
        SwitchRow(stringResource(R.string.privacy_daily), stringResource(R.string.privacy_daily_desc), settings.dailySummary, viewModel::setDailySummary)
        OutlinedButton(onClick = { confirmDelete = true }) { Text(stringResource(R.string.delete_all)) }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SectionTitle(R.string.settings_permissions)
        // resumeTick forces re-evaluation of the status values after returning from system settings.
        PermissionRow(R.string.perm_mic_title, Permissions.hasMic(context), resumeTick) {
            rationale = Rationale(R.string.perm_mic_title, R.string.perm_mic_why) {
                micRationaleFor = "mic"
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        PermissionRow(R.string.perm_notif_title, Permissions.hasPostNotifications(context), resumeTick) {
            rationale = Rationale(R.string.perm_notif_title, R.string.perm_notif_why) {
                if (Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        PermissionRow(R.string.perm_listener_title, Permissions.listenerEnabled(context), resumeTick) {
            rationale = Rationale(R.string.perm_listener_title, R.string.perm_listener_why) {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        PermissionRow(R.string.perm_battery_title, Permissions.ignoringBatteryOptimizations(context), resumeTick) {
            rationale = Rationale(R.string.perm_battery_title, R.string.perm_battery_why) {
                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        Text(stringResource(R.string.docomo_tip), style = MaterialTheme.typography.bodySmall)
    }
}

private class Rationale(val title: Int, val message: Int, val onConfirm: () -> Unit)

@Composable
private fun SectionTitle(res: Int) {
    Text(stringResource(res), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
}

@Composable
@Suppress("UNUSED_PARAMETER")
private fun PermissionRow(title: Int, granted: Boolean, refreshKey: Int, onRequest: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), style = MaterialTheme.typography.bodyLarge)
            Text(
                stringResource(if (granted) R.string.granted else R.string.not_granted),
                style = MaterialTheme.typography.bodySmall,
                color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
        if (!granted) OutlinedButton(onClick = onRequest) { Text(stringResource(R.string.grant)) }
    }
}
