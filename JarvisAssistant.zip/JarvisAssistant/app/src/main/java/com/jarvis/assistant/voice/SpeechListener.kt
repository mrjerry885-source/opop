package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

sealed interface ListenResult {
    data class Text(val value: String) : ListenResult
    data object NoSpeech : ListenResult
    data object PermissionDenied : ListenResult
    data object Unavailable : ListenResult
    data class Failure(val code: Int) : ListenResult
}

/** One-shot speech recognition using the system SpeechRecognizer. All calls run on the main thread. */
class SpeechListener(private val context: Context) {

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    suspend fun listenOnce(
        languageTag: String,
        preferOffline: Boolean = false,
        onPartial: (String) -> Unit = {}
    ): ListenResult = withContext(Dispatchers.Main.immediate) {
        if (!isAvailable()) return@withContext ListenResult.Unavailable
        suspendCancellableCoroutine<ListenResult> { continuation ->
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            var destroyed = false
            fun destroy() {
                if (!destroyed) {
                    destroyed = true
                    recognizer.destroy()
                }
            }
            fun finish(result: ListenResult) {
                if (continuation.isActive) continuation.resume(result)
                destroy()
            }

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = Unit
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit

                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let(onPartial)
                }

                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim().orEmpty()
                    finish(if (text.isEmpty()) ListenResult.NoSpeech else ListenResult.Text(text))
                }

                override fun onError(error: Int) {
                    finish(
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH,
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ListenResult.NoSpeech
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> ListenResult.PermissionDenied
                            else -> ListenResult.Failure(error)
                        }
                    )
                }
            })

            continuation.invokeOnCancellation {
                Handler(Looper.getMainLooper()).post { destroy() }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            recognizer.startListening(intent)
        }
    }
}
