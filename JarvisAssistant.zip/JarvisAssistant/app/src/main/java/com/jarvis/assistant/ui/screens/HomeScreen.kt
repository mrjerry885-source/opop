package com.jarvis.assistant.ui.screens

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.R
import com.jarvis.assistant.ui.MainViewModel
import com.jarvis.assistant.ui.Permissions
import com.jarvis.assistant.voice.VoiceState

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val state by viewModel.voiceState.collectAsStateWithLifecycle()
    val partial by viewModel.partial.collectAsStateWithLifecycle()
    val lines by viewModel.lines.collectAsStateWithLifecycle()
    val bengaliVoice by viewModel.bengaliVoice.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var showMicRationale by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.toggleVoice()
    }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.size - 1)
    }

    if (showMicRationale) {
        RationaleDialog(
            title = stringResource(R.string.perm_mic_title),
            message = stringResource(R.string.perm_mic_why),
            onConfirm = {
                showMicRationale = false
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onDismiss = { showMicRationale = false }
        )
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (bengaliVoice == false) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.tts_missing))
                    Button(onClick = {
                        try {
                            context.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
                        } catch (e: ActivityNotFoundException) {
                            // No TTS engine offers a data installer on this device.
                        }
                    }) { Text(stringResource(R.string.tts_install)) }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(lines) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (line.fromUser) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) { Text(line.text, Modifier.padding(12.dp)) }
                }
            }
            if (partial.isNotBlank()) {
                item {
                    Text(partial, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        VoiceOrb(state) {
            if (Permissions.hasMic(context)) viewModel.toggleVoice() else showMicRationale = true
        }
        Text(
            stringResource(
                when (state) {
                    VoiceState.Idle -> R.string.state_idle
                    VoiceState.Listening -> R.string.state_listening
                    VoiceState.Thinking -> R.string.state_thinking
                    VoiceState.Speaking -> R.string.state_speaking
                }
            ),
            Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.titleMedium
        )

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.text_input_hint)) },
                singleLine = true
            )
            IconButton(
                onClick = {
                    viewModel.sendText(input)
                    input = ""
                },
                enabled = input.isNotBlank() && state == VoiceState.Idle
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send)) }
        }
    }
}

@Composable
private fun VoiceOrb(state: VoiceState, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val color = when (state) {
        VoiceState.Idle -> MaterialTheme.colorScheme.primary
        VoiceState.Listening -> MaterialTheme.colorScheme.tertiary
        VoiceState.Thinking -> MaterialTheme.colorScheme.secondary
        VoiceState.Speaking -> MaterialTheme.colorScheme.primary
    }
    val description = stringResource(R.string.orb_description)
    Box(
        Modifier
            .size(140.dp)
            .scale(if (state == VoiceState.Idle) 1f else pulse)
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Text("🎙️", fontSize = 48.sp)
    }
}
