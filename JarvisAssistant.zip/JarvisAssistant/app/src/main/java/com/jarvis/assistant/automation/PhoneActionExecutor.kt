package com.jarvis.assistant.automation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import com.jarvis.assistant.R
import com.jarvis.assistant.core.AppVisibility
import com.jarvis.assistant.data.memory.MemoryKind
import com.jarvis.assistant.data.memory.MemoryRepository
import com.jarvis.assistant.data.settings.SettingsRepository
import com.jarvis.assistant.domain.PhoneAction
import java.util.Locale

/**
 * Runs phone actions using public Android APIs only. Actions that need a screen are launched directly
 * when the app is visible; otherwise a notification is posted, because Android blocks background
 * activity launches.
 */
class PhoneActionExecutor(
    private val context: Context,
    private val reminders: ReminderScheduler,
    private val memory: MemoryRepository,
    private val settings: SettingsRepository
) {
    suspend fun execute(action: PhoneAction): String = when (action) {
        is PhoneAction.Flashlight -> flashlight(action.on)
        is PhoneAction.Alarm -> alarm(action)
        is PhoneAction.Timer -> timer(action)
        is PhoneAction.Dial -> dial(action)
        is PhoneAction.OpenApp -> openApp(action.name)
        is PhoneAction.Remember -> remember(action.text)
        is PhoneAction.Remind -> {
            reminders.schedule(action.text, action.minutes)
            context.getString(R.string.action_reminder_set, action.minutes)
        }
        PhoneAction.SummarizeNotifications -> context.getString(R.string.action_failed)
    }

    private fun flashlight(on: Boolean): String {
        val ok = try {
            val manager = context.getSystemService(CameraManager::class.java)
            val id = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) false else {
                manager.setTorchMode(id, on)
                true
            }
        } catch (e: Exception) {
            false
        }
        return context.getString(
            when {
                !ok -> R.string.action_flashlight_failed
                on -> R.string.action_flashlight_on
                else -> R.string.action_flashlight_off
            }
        )
    }

    private fun alarm(action: PhoneAction.Alarm): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, action.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val label = String.format(Locale.ROOT, "%02d:%02d", action.hour, action.minute)
        return if (launchOrNotify(intent)) context.getString(R.string.action_alarm_set, label)
        else context.getString(R.string.action_failed)
    }

    private fun timer(action: PhoneAction.Timer): String {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, action.seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launchOrNotify(intent)) context.getString(R.string.action_timer_set)
        else context.getString(R.string.action_failed)
    }

    private fun dial(action: PhoneAction.Dial): String {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(action.number)))
        return if (launchOrNotify(intent)) context.getString(R.string.action_dial_opened)
        else context.getString(R.string.action_failed)
    }

    @Suppress("DEPRECATION")
    private fun openApp(name: String): String {
        val pm = context.packageManager
        val query = name.lowercase(Locale.ROOT)
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(query) }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            ?: return context.getString(R.string.action_app_not_found, name)
        return if (launchOrNotify(launch)) context.getString(R.string.action_app_opened, name)
        else context.getString(R.string.action_failed)
    }

    private suspend fun remember(text: String): String {
        if (!settings.current.memoryEnabled) return context.getString(R.string.action_memory_disabled)
        memory.add(text, MemoryKind.NOTE)
        return context.getString(R.string.action_memory_saved)
    }

    private fun launchOrNotify(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!AppVisibility.inForeground) {
            Notifications.postActionPrompt(context, intent)
            return true
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }
}
