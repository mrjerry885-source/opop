package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.R
import com.jarvis.assistant.domain.AssistantEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex

enum class VoiceState { Idle, Listening, Thinking, Speaking }

data class TranscriptLine(val fromUser: Boolean, val text: String)

/** One listen → think → speak turn, shared by the UI and the background wake word service. */
class VoiceConversation(
    private val context: Context,
    private val engine: AssistantEngine,
    private val tts: BengaliTts,
    private val listener: SpeechListener
) {
    private val gate = Mutex()
    private val _state = MutableStateFlow(VoiceState.Idle)
    private val _partial = MutableStateFlow("")
    private val _lines = MutableStateFlow<List<TranscriptLine>>(emptyList()) // RAM only

    val state: StateFlow<VoiceState> = _state.asStateFlow()
    val partial: StateFlow<String> = _partial.asStateFlow()
    val lines: StateFlow<List<TranscriptLine>> = _lines.asStateFlow()

    suspend fun converse(greet: Boolean) {
        if (!gate.tryLock()) return
        try {
            if (greet) say(context.getString(R.string.greeting_ready), addToTranscript = false)
            _state.value = VoiceState.Listening
            when (val heard = listener.listenOnce("bn-BD", onPartial = { _partial.value = it })) {
                is ListenResult.Text -> respond(heard.value)
                ListenResult.NoSpeech -> say(context.getString(R.string.err_no_speech))
                ListenResult.PermissionDenied -> say(context.getString(R.string.need_mic_first))
                ListenResult.Unavailable -> say(context.getString(R.string.err_recognizer_unavailable))
                is ListenResult.Failure -> say(context.getString(R.string.err_recognizer_failed))
            }
        } finally {
            tts.stop()
            _partial.value = ""
            _state.value = VoiceState.Idle
            gate.unlock()
        }
    }

    suspend fun submitText(text: String) {
        if (text.isBlank() || !gate.tryLock()) return
        try {
            respond(text.trim())
        } finally {
            tts.stop()
            _state.value = VoiceState.Idle
            gate.unlock()
        }
    }

    private suspend fun respond(userText: String) {
        append(TranscriptLine(fromUser = true, text = userText))
        _partial.value = ""
        _state.value = VoiceState.Thinking
        say(engine.handle(userText))
    }

    private suspend fun say(text: String, addToTranscript: Boolean = true) {
        if (addToTranscript) append(TranscriptLine(fromUser = false, text = text))
        _state.value = VoiceState.Speaking
        tts.speak(text)
    }

    private fun append(line: TranscriptLine) {
        _lines.value = (_lines.value + line).takeLast(MAX_LINES)
    }

    fun clearTranscript() {
        _lines.value = emptyList()
    }

    private companion object {
        const val MAX_LINES = 50
    }
}
