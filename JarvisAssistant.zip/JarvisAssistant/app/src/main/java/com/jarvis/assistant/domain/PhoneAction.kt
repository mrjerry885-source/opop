package com.jarvis.assistant.domain

sealed interface PhoneAction {
    data class Flashlight(val on: Boolean) : PhoneAction
    data class Alarm(val hour: Int, val minute: Int) : PhoneAction
    data class Timer(val seconds: Int) : PhoneAction
    data class Dial(val number: String) : PhoneAction
    data class OpenApp(val name: String) : PhoneAction
    data class Remember(val text: String) : PhoneAction
    data class Remind(val text: String, val minutes: Int) : PhoneAction
    data object SummarizeNotifications : PhoneAction
}
