package com.jarvis.assistant.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.automation.Notifications
import com.jarvis.assistant.core.AppVisibility
import com.jarvis.assistant.voice.SpeechKeywordWakeWordEngine
import com.jarvis.assistant.voice.WakeWordUnavailableException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground (microphone) service that listens for "Hey JARVIS" while the app is not on screen.
 * It must be started while the app is visible: Android 12+ forbids starting it from the background.
 */
class WakeWordService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            (application as JarvisApp).container.settings.update { it.copy(wakeWord = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            ServiceCompat.startForeground(
                this, Notifications.SERVICE_NOTIFICATION_ID, Notifications.serviceNotification(this), type
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (job == null) job = scope.launch { runLoop() }
        return START_NOT_STICKY
    }

    private suspend fun runLoop() {
        val container = (application as JarvisApp).container
        val engine = SpeechKeywordWakeWordEngine(container.listener)
        // While the app is on screen the UI owns the microphone, so listening pauses and resumes automatically.
        AppVisibility.foreground.collectLatest { visible ->
            if (visible) return@collectLatest
            try {
                while (scope.isActive) {
                    engine.awaitWakeWord()
                    container.conversation.converse(greet = true)
                }
            } catch (e: WakeWordUnavailableException) {
                container.settings.update { it.copy(wakeWord = false) }
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_WAKE_WORD"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, WakeWordService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}
