package com.jarvis.assistant.domain

import android.content.Context
import com.jarvis.assistant.R
import com.jarvis.assistant.automation.NotificationAccess
import com.jarvis.assistant.automation.PhoneActionExecutor
import com.jarvis.assistant.data.ai.AiBackend
import com.jarvis.assistant.data.ai.ChatTurn
import com.jarvis.assistant.data.memory.MemoryKind
import com.jarvis.assistant.data.memory.MemoryRepository
import com.jarvis.assistant.data.settings.SettingsRepository
import java.text.DateFormat
import java.util.Date

/** Turns one user utterance into a spoken Bengali reply, running phone actions on the way. */
class AssistantEngine(
    private val context: Context,
    private val settings: SettingsRepository,
    private val memory: MemoryRepository,
    private val backend: AiBackend,
    private val executor: PhoneActionExecutor
) {
    private val history = ArrayDeque<ChatTurn>() // RAM only, never persisted

    suspend fun handle(utterance: String): String {
        val local = IntentRouter.route(utterance)
        val reply = if (local != null) run(local) else askAi(utterance)
        logExchange(utterance, reply)
        return reply
    }

    private suspend fun run(action: PhoneAction): String =
        if (action is PhoneAction.SummarizeNotifications) summarizeNotifications() else executor.execute(action)

    private suspend fun askAi(utterance: String): String {
        if (!backend.isConfigured()) return context.getString(R.string.err_backend_not_configured)
        val notes = if (settings.current.memoryEnabled) memory.promptContext() else emptyList()
        val now = DateFormat.getDateTimeInstance().format(Date())
        val turns = history.toList() + ChatTurn("user", utterance)
        val raw = backend.chat(SystemPrompt.build(notes, now), turns).getOrElse {
            return context.getString(R.string.err_backend_failed)
        }
        val parsed = ActionParser.parse(raw)
        remember(ChatTurn("user", utterance))
        remember(ChatTurn("assistant", parsed.spokenText.ifBlank { raw }))
        val actionResult = parsed.action?.let { run(it) }
        return listOfNotNull(parsed.spokenText.takeIf { it.isNotBlank() }, actionResult).joinToString(" ")
    }

    private fun remember(turn: ChatTurn) {
        history.addLast(turn)
        while (history.size > MAX_HISTORY) history.removeFirst()
    }

    private suspend fun summarizeNotifications(): String {
        val s = settings.current
        if (!s.collectNotifications || !NotificationAccess.isEnabled(context)) {
            return context.getString(R.string.notif_summary_needs_access)
        }
        val items = memory.notificationsSince(System.currentTimeMillis() - DAY_MS)
        if (items.isEmpty()) return context.getString(R.string.notif_summary_none)

        if (s.shareNotificationsWithAi && backend.isConfigured()) {
            val payload = items.takeLast(MAX_NOTIFICATIONS_TO_AI)
                .joinToString("\n") { "${it.appLabel}: ${it.title} - ${it.text}" }
            val ai = backend.chat(SystemPrompt.NOTIFICATION_SUMMARY, listOf(ChatTurn("user", payload))).getOrNull()
            if (!ai.isNullOrBlank()) return ActionParser.parse(ai).spokenText
        }

        val breakdown = items.groupingBy { it.appLabel }.eachCount().entries
            .sortedByDescending { it.value }.take(5)
            .joinToString(", ") { context.getString(R.string.notif_summary_item, it.key, it.value) }
        return context.getString(R.string.notif_summary_local, items.size, breakdown)
    }

    private suspend fun logExchange(utterance: String, reply: String) {
        val s = settings.current
        if (s.memoryEnabled && s.logConversations) {
            memory.add("User: $utterance\nAssistant: $reply", MemoryKind.LOG)
        }
    }

    private companion object {
        const val MAX_HISTORY = 12
        const val MAX_NOTIFICATIONS_TO_AI = 40
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
