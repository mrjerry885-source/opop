package com.jarvis.assistant.voice

import java.util.Locale

/** Matches recognizer output against the "Hey JARVIS" wake phrase, tolerating common mis-hearings. */
object WakePhrase {
    private val variants = listOf("jarvis", "jarvas", "jervis", "jarvice", "জার্ভিস", "জারভিস", "জার্ভিছ")

    fun matches(recognized: String): Boolean {
        val text = recognized.lowercase(Locale.ROOT)
        return variants.any { text.contains(it) }
    }
}
