package com.jarvis.assistant.data.ai

import com.jarvis.assistant.data.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

@Serializable
data class ChatTurn(val role: String, val content: String)

@Serializable
private data class ChatRequest(val system: String, val messages: List<ChatTurn>)

@Serializable
private data class ChatResponse(val reply: String = "")

interface AiBackend {
    fun isConfigured(): Boolean
    suspend fun chat(system: String, turns: List<ChatTurn>): Result<String>
}

/**
 * Talks to a user-owned proxy server. The proxy holds the real AI provider key,
 * so no provider key is ever stored in or shipped with the app.
 */
class ProxyAiBackend(
    private val settings: SettingsRepository,
    private val client: OkHttpClient
) : AiBackend {

    private val json = Json { ignoreUnknownKeys = true }

    override fun isConfigured(): Boolean =
        settings.current.backendUrl.startsWith("https://") && !settings.token().isNullOrBlank()

    override suspend fun chat(system: String, turns: List<ChatTurn>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = settings.current.backendUrl
                val token = settings.token()
                require(url.startsWith("https://") && !token.isNullOrBlank()) { "Backend is not configured" }
                val payload = json.encodeToString(ChatRequest.serializer(), ChatRequest(system, turns))
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .post(payload.toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
                    val body = response.body?.string().orEmpty()
                    val reply = json.decodeFromString(ChatResponse.serializer(), body).reply
                    if (reply.isBlank()) throw IOException("Empty reply")
                    reply
                }
            }
        }
}
