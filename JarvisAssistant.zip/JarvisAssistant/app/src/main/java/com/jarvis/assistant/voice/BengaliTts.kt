package com.jarvis.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Bengali text-to-speech. Tries bn-BD, then bn-IN, then generic bn voices. */
class BengaliTts(context: Context) {
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private val initResult = CompletableDeferred<Boolean>()
    private val _bengaliAvailable = MutableStateFlow<Boolean?>(null)

    /** null while initialising, then true or false. */
    val bengaliAvailable: StateFlow<Boolean?> = _bengaliAvailable.asStateFlow()

    private var engine: TextToSpeech? = null

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            val tts = engine
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = complete(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = complete(utteranceId)
                    override fun onStop(utteranceId: String?, interrupted: Boolean) = complete(utteranceId)
                })
                _bengaliAvailable.value = selectBengali(tts)
                initResult.complete(true)
            } else {
                _bengaliAvailable.value = false
                initResult.complete(false)
            }
        }
    }

    /** Speaks the text and suspends until playback ends. Does nothing if no Bengali voice exists. */
    suspend fun speak(text: String) {
        if (!initResult.await() || _bengaliAvailable.value != true || text.isBlank()) return
        val tts = engine ?: return
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Unit>()
        pending[id] = done
        try {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            withTimeoutOrNull(SPEAK_TIMEOUT_MS) { done.await() }
        } finally {
            pending.remove(id)
        }
    }

    fun stop() {
        engine?.stop()
    }

    private fun complete(id: String?) {
        id?.let { pending[it]?.complete(Unit) }
    }

    private fun selectBengali(tts: TextToSpeech): Boolean {
        val candidates = listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("bn"))
        return candidates.any {
            val result = tts.setLanguage(it)
            result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private companion object {
        const val SPEAK_TIMEOUT_MS = 90_000L
    }
}
