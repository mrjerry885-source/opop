package com.jarvis.assistant.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.jarvis.assistant.JarvisApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ID, -1)
        val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
        if (id < 0 || text.isEmpty()) return
        Notifications.postReminder(context, id, text)
        val pending = goAsync()
        val container = (context.applicationContext as JarvisApp).container
        CoroutineScope(Dispatchers.IO).launch {
            try {
                container.db.reminderDao().markDone(id)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val EXTRA_ID = "reminder_id"
        const val EXTRA_TEXT = "reminder_text"
    }
}
