package com.jarvis.assistant.data.memory

import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val db: JarvisDatabase) {
    private val memories = db.memoryDao()
    private val notifications = db.notificationLogDao()

    fun observeMemories(): Flow<List<MemoryEntity>> = memories.observeAll()
    fun observeReminders(): Flow<List<ReminderEntity>> = db.reminderDao().observeAll()

    suspend fun add(text: String, kind: String) {
        memories.insert(MemoryEntity(text = text.take(MAX_TEXT), kind = kind, createdAt = System.currentTimeMillis()))
    }

    suspend fun promptContext(): List<String> =
        memories.recent(listOf(MemoryKind.NOTE, MemoryKind.SUMMARY), PROMPT_LIMIT).map { it.text }

    suspend fun since(timestamp: Long): List<MemoryEntity> = memories.since(timestamp)
    suspend fun delete(id: Long) = memories.delete(id)

    suspend fun logNotification(appLabel: String, title: String, text: String) {
        notifications.insert(
            NotificationLogEntity(
                appLabel = appLabel.take(80),
                title = title.take(160),
                text = text.take(400),
                postedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun notificationsSince(timestamp: Long): List<NotificationLogEntity> = notifications.since(timestamp)

    suspend fun prune(retentionDays: Int = RETENTION_DAYS) {
        val cutoff = System.currentTimeMillis() - retentionDays * DAY_MS
        memories.pruneOlderThan(cutoff)
        notifications.pruneOlderThan(cutoff)
    }

    suspend fun wipeMemoriesAndLogs() {
        memories.deleteAll()
        notifications.deleteAll()
    }

    companion object {
        const val RETENTION_DAYS = 30
        private const val DAY_MS = 24L * 60 * 60 * 1000
        private const val MAX_TEXT = 2000
        private const val PROMPT_LIMIT = 20
    }
}
