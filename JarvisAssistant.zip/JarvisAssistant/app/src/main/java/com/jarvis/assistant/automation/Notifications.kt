package com.jarvis.assistant.automation

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.service.WakeWordService
import com.jarvis.assistant.ui.MainActivity

object Notifications {
    const val CHANNEL_SERVICE = "wake_service"
    const val CHANNEL_REMINDERS = "reminders"
    const val CHANNEL_SUMMARY = "daily_summary"
    const val CHANNEL_PROMPTS = "action_prompts"
    const val SERVICE_NOTIFICATION_ID = 1001

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_SERVICE, context.getString(R.string.channel_service), NotificationManager.IMPORTANCE_LOW)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_REMINDERS, context.getString(R.string.channel_reminders), NotificationManager.IMPORTANCE_HIGH)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_SUMMARY, context.getString(R.string.channel_summary), NotificationManager.IMPORTANCE_DEFAULT)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_PROMPTS, context.getString(R.string.channel_prompts), NotificationManager.IMPORTANCE_HIGH)
        )
    }

    fun serviceNotification(context: Context): Notification {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            context, 1,
            Intent(context, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(context.getString(R.string.service_title))
            .setContentText(context.getString(R.string.service_text))
            .setContentIntent(open)
            .addAction(0, context.getString(R.string.service_stop), stop)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    fun postReminder(context: Context, id: Long, text: String) =
        post(context, CHANNEL_REMINDERS, 2000 + id.toInt(), context.getString(R.string.reminder_title), text, null)

    fun postSummary(context: Context, text: String) =
        post(context, CHANNEL_SUMMARY, 3000, context.getString(R.string.daily_summary_title), text, null)

    fun postActionPrompt(context: Context, intent: Intent) =
        post(context, CHANNEL_PROMPTS, 4000, context.getString(R.string.app_name),
            context.getString(R.string.action_needs_tap), intent)

    @SuppressLint("MissingPermission")
    private fun post(context: Context, channel: String, id: Int, title: String, text: String, tapIntent: Intent?) {
        val manager = NotificationManagerCompat.from(context)
        if (!manager.areNotificationsEnabled()) return
        val builder = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
        if (tapIntent != null) {
            builder.setContentIntent(PendingIntent.getActivity(context, id, tapIntent, PendingIntent.FLAG_IMMUTABLE))
        }
        manager.notify(id, builder.build())
    }
}
