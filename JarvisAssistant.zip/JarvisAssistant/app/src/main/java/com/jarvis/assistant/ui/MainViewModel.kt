package com.jarvis.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.settings.AppSettings
import com.jarvis.assistant.service.WakeWordService
import com.jarvis.assistant.voice.VoiceState
import com.jarvis.assistant.work.DailySummaryScheduler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as JarvisApp).container
    private var voiceJob: Job? = null

    val voiceState = container.conversation.state
    val partial = container.conversation.partial
    val lines = container.conversation.lines
    val settings: StateFlow<AppSettings> = container.settings.flow
    val bengaliVoice = container.tts.bengaliAvailable

    val memories = container.memoryRepo.observeMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val reminders = container.memoryRepo.observeReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun toggleVoice() {
        if (voiceState.value != VoiceState.Idle) {
            voiceJob?.cancel()
            container.tts.stop()
        } else {
            voiceJob = viewModelScope.launch { container.conversation.converse(greet = false) }
        }
    }

    fun sendText(text: String) {
        voiceJob = viewModelScope.launch { container.conversation.submitText(text) }
    }

    fun saveBackend(url: String, token: String) {
        container.settings.update { it.copy(backendUrl = url.trim()) }
        if (token.isNotBlank()) container.settings.setToken(token.trim())
    }

    fun hasToken(): Boolean = !container.settings.token().isNullOrBlank()

    fun setWakeWord(enabled: Boolean) {
        container.settings.update { it.copy(wakeWord = enabled) }
        val app = getApplication<Application>()
        if (enabled) WakeWordService.start(app) else WakeWordService.stop(app)
    }

    fun setMemory(enabled: Boolean) = container.settings.update { it.copy(memoryEnabled = enabled) }
    fun setLogConversations(enabled: Boolean) = container.settings.update { it.copy(logConversations = enabled) }
    fun setCollectNotifications(enabled: Boolean) = container.settings.update { it.copy(collectNotifications = enabled) }
    fun setShareNotifications(enabled: Boolean) = container.settings.update { it.copy(shareNotificationsWithAi = enabled) }

    fun setDailySummary(enabled: Boolean) {
        container.settings.update { it.copy(dailySummary = enabled) }
        DailySummaryScheduler.sync(getApplication(), enabled)
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { container.memoryRepo.delete(id) }
    }

    fun deleteReminder(id: Long) {
        viewModelScope.launch { container.reminders.cancel(id) }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            container.reminders.cancelAll()
            container.memoryRepo.wipeMemoriesAndLogs()
            container.conversation.clearTranscript()
        }
    }
}
