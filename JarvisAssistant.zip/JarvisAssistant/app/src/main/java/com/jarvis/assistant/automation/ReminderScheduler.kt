package com.jarvis.assistant.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.jarvis.assistant.data.memory.ReminderDao
import com.jarvis.assistant.data.memory.ReminderEntity

/** Schedules reminders with inexact alarms, so no special exact-alarm permission is needed. */
class ReminderScheduler(private val context: Context, private val dao: ReminderDao) {

    suspend fun schedule(text: String, minutes: Int): Long {
        val at = System.currentTimeMillis() + minutes * 60_000L
        val id = dao.insert(ReminderEntity(text = text, triggerAt = at))
        setAlarm(id, text, at)
        return id
    }

    suspend fun rescheduleAll() {
        val now = System.currentTimeMillis()
        dao.pending().forEach { setAlarm(it.id, it.text, maxOf(it.triggerAt, now + 5_000)) }
    }

    suspend fun cancel(id: Long) {
        alarmManager().cancel(pendingIntent(id, ""))
        dao.delete(id)
    }

    suspend fun cancelAll() {
        dao.pending().forEach { alarmManager().cancel(pendingIntent(it.id, it.text)) }
        dao.deleteAll()
    }

    private fun setAlarm(id: Long, text: String, at: Long) {
        alarmManager().setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent(id, text))
    }

    private fun alarmManager() = context.getSystemService(AlarmManager::class.java)

    private fun pendingIntent(id: Long, text: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra(ReminderReceiver.EXTRA_ID, id)
            .putExtra(ReminderReceiver.EXTRA_TEXT, text)
        return PendingIntent.getBroadcast(
            context, id.toInt(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
