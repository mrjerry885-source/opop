package com.jarvis.assistant.data.memory

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

object MemoryKind {
    const val NOTE = "NOTE"
    const val LOG = "LOG"
    const val SUMMARY = "SUMMARY"
}

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val kind: String,
    val createdAt: Long
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAt: Long,
    val done: Boolean = false
)

@Entity(tableName = "notification_log")
data class NotificationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appLabel: String,
    val title: String,
    val text: String,
    val postedAt: Long
)

@Dao
interface MemoryDao {
    @Insert suspend fun insert(entity: MemoryEntity): Long

    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE kind IN (:kinds) ORDER BY createdAt DESC LIMIT :limit")
    suspend fun recent(kinds: List<String>, limit: Int): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE createdAt >= :since ORDER BY createdAt ASC")
    suspend fun since(since: Long): List<MemoryEntity>

    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memories WHERE createdAt < :cutoff AND kind != 'NOTE'") suspend fun pruneOlderThan(cutoff: Long)
    @Query("DELETE FROM memories") suspend fun deleteAll()
}

@Dao
interface ReminderDao {
    @Insert suspend fun insert(entity: ReminderEntity): Long

    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE done = 0")
    suspend fun pending(): List<ReminderEntity>

    @Query("UPDATE reminders SET done = 1 WHERE id = :id") suspend fun markDone(id: Long)
    @Query("DELETE FROM reminders WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM reminders") suspend fun deleteAll()
}

@Dao
interface NotificationLogDao {
    @Insert suspend fun insert(entity: NotificationLogEntity): Long

    @Query("SELECT * FROM notification_log WHERE postedAt >= :since ORDER BY postedAt ASC")
    suspend fun since(since: Long): List<NotificationLogEntity>

    @Query("DELETE FROM notification_log WHERE postedAt < :cutoff") suspend fun pruneOlderThan(cutoff: Long)
    @Query("DELETE FROM notification_log") suspend fun deleteAll()
}

@Database(
    entities = [MemoryEntity::class, ReminderEntity::class, NotificationLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun reminderDao(): ReminderDao
    abstract fun notificationLogDao(): NotificationLogDao
}
