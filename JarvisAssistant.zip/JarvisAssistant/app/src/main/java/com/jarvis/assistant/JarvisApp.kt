package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.automation.Notifications
import com.jarvis.assistant.core.AppContainer
import com.jarvis.assistant.work.DailySummaryScheduler

class JarvisApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifications.createChannels(this)
        DailySummaryScheduler.sync(this, container.settings.current.dailySummary)
    }
}
