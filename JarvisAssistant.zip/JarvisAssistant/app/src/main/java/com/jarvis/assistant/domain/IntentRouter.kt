package com.jarvis.assistant.domain

import java.util.Locale

/**
 * Fast, offline routing of common Bengali and English phone commands.
 * Anything it does not recognise is sent to the AI backend instead.
 */
object IntentRouter {

    private val wordRegex = Regex("[\\p{L}\\p{M}]+")
    private val timeRegex = Regex("(\\d{1,2})(?:[:.](\\d{2}))?")
    private val durationRegex = Regex(
        "(\\d+)\\s*(সেকেন্ড|সেকেণ্ড|seconds?|secs?|মিনিট|minutes?|mins?|ঘণ্টা|ঘন্টা|hours?|hrs?)"
    )
    private val phoneRegex = Regex("\\+?\\d[\\d\\s\\-]{4,}\\d")
    private val rememberRegex = Regex("(মনে রাখো|মনে রেখো|remember that|remember)")
    private val openSuffixRegex = Regex("^(.+?)\\s*(খোলো|খুলো|ওপেন করো|ওপেন কর)$")
    private val openPrefixRegex = Regex("^(?:open|launch)\\s+(.+)$")

    private val appAliases = mapOf(
        "ইউটিউব" to "youtube", "ক্যামেরা" to "camera", "ফেসবুক" to "facebook",
        "হোয়াটসঅ্যাপ" to "whatsapp", "গুগল ম্যাপ" to "maps", "ম্যাপ" to "maps",
        "সেটিংস" to "settings", "ক্রোম" to "chrome", "জিমেইল" to "gmail",
        "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock", "ছবি" to "photos",
        "গ্যালারি" to "gallery", "মেসেজ" to "messages"
    )

    fun route(raw: String): PhoneAction? {
        val text = TextNormalizer.normalize(raw)
        if (text.isBlank()) return null
        val tokens = wordRegex.findAll(text).map { it.value }.toList()

        if (text.containsAny("নোটিফিকেশন", "notification") &&
            text.containsAny("সারাংশ", "সামারি", "summar", "পড়ে", "পড়ো", "শোনাও", "বলো", "read")
        ) return PhoneAction.SummarizeNotifications

        rememberRegex.find(text)?.let { match ->
            val note = text.removeRange(match.range).trim(' ', ',', ':', '।', '.')
            if (note.isNotBlank()) return PhoneAction.Remember(note)
        }

        if (text.containsAny("মনে করিয়ে দাও", "মনে করিয়ে দিও", "remind me")) {
            val seconds = parseDurationSeconds(text) ?: return null
            val note = text.replace("মনে করিয়ে দাও", "").replace("মনে করিয়ে দিও", "")
                .replace("remind me", "").trim(' ', ',', '।', '.')
            return PhoneAction.Remind(note.ifBlank { text }, maxOf(1, seconds / 60))
        }

        if (text.containsAny("টাইমার", "timer")) {
            return parseDurationSeconds(text)?.let { PhoneAction.Timer(it) }
        }

        if (text.containsAny("অ্যালার্ম", "এলার্ম", "অ্যালারাম", "এলারাম", "alarm")) {
            return parseAlarm(text)
        }

        if (text.containsAny("ফ্ল্যাশ", "টর্চ", "flashlight", "torch")) {
            val off = text.containsAny("নিভাও", "নিভিয়ে", "বন্ধ") || "off" in tokens || "অফ" in tokens
            if (off) return PhoneAction.Flashlight(false)
            val on = text.containsAny("জ্বালাও", "জ্বালিয়ে", "চালু") || "on" in tokens || "অন" in tokens
            return if (on) PhoneAction.Flashlight(true) else null
        }

        if (text.containsAny("কল করো", "ফোন করো", "কল দাও", "dial") || "call" in tokens) {
            phoneRegex.find(text)?.let { m ->
                return PhoneAction.Dial(m.value.filter { it.isDigit() || it == '+' })
            }
        }

        openSuffixRegex.find(text)?.let { return PhoneAction.OpenApp(resolveApp(it.groupValues[1])) }
        openPrefixRegex.find(text)?.let { return PhoneAction.OpenApp(resolveApp(it.groupValues[1])) }
        return null
    }

    private fun resolveApp(name: String): String {
        val trimmed = name.trim()
        return appAliases[trimmed] ?: trimmed
    }

    private fun parseAlarm(text: String): PhoneAction? {
        val match = timeRegex.find(text) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].ifEmpty { "0" }.toIntOrNull() ?: return null
        val isPm = text.containsAny("বিকাল", "বিকেল", "দুপুর", "সন্ধ্যা", "রাত", "pm", "evening", "afternoon", "night")
        val isAm = text.containsAny("সকাল", "ভোর", "am", "morning")
        if (isPm && hour in 1..11) hour += 12
        if (isAm && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) return null
        return PhoneAction.Alarm(hour, minute)
    }

    internal fun parseDurationSeconds(text: String): Int? {
        val match = durationRegex.find(text) ?: return null
        val amount = match.groupValues[1].toIntOrNull() ?: return null
        val unit = match.groupValues[2]
        val multiplier = when {
            unit.startsWith("সে") || unit.startsWith("sec") -> 1
            unit.startsWith("মি") || unit.startsWith("min") -> 60
            else -> 3600
        }
        val seconds = amount.toLong() * multiplier
        return if (seconds in 1..86_400) seconds.toInt() else null
    }

    private fun String.containsAny(vararg needles: String) = needles.any { contains(it) }
}

object TextNormalizer {
    fun normalize(raw: String): String {
        val lowered = raw.trim().lowercase(Locale.ROOT)
        val sb = StringBuilder(lowered.length)
        for (ch in lowered) {
            sb.append(if (ch in '\u09E6'..'\u09EF') ('0' + (ch - '\u09E6')) else ch)
        }
        return sb.toString().trimEnd('।', '.', '?', '!', ' ')
    }
}
