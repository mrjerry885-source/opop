package com.jarvis.assistant.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R
import com.jarvis.assistant.automation.Notifications
import com.jarvis.assistant.data.ai.ChatTurn
import com.jarvis.assistant.data.memory.MemoryKind
import com.jarvis.assistant.domain.ActionParser
import com.jarvis.assistant.domain.SystemPrompt
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

class DailySummaryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as JarvisApp).container
        val settings = container.settings.current
        container.memoryRepo.prune()
        if (!settings.memoryEnabled || !settings.dailySummary) return Result.success()

        val startOfDay = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val entries = container.memoryRepo.since(startOfDay).filter { it.kind != MemoryKind.SUMMARY }
        if (entries.isEmpty()) return Result.success()

        var summary: String? = null
        if (container.backend.isConfigured()) {
            val payload = entries.takeLast(MAX_ENTRIES).joinToString("\n---\n") { it.text }
            summary = container.backend.chat(SystemPrompt.DAILY_SUMMARY, listOf(ChatTurn("user", payload)))
                .getOrNull()?.let { ActionParser.parse(it).spokenText }?.takeIf { it.isNotBlank() }
        }
        val text = summary ?: applicationContext.getString(R.string.daily_summary_local, entries.size)
        container.memoryRepo.add(text, MemoryKind.SUMMARY)
        Notifications.postSummary(applicationContext, text)
        return Result.success()
    }

    private companion object {
        const val MAX_ENTRIES = 60
    }
}

object DailySummaryScheduler {
    private const val WORK_NAME = "daily_summary"

    fun sync(context: Context, enabled: Boolean) {
        val workManager = WorkManager.getInstance(context)
        if (!enabled) {
            workManager.cancelUniqueWork(WORK_NAME)
            return
        }
        val now = LocalDateTime.now()
        var next = now.with(LocalTime.of(21, 0))
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next)
        val request = PeriodicWorkRequestBuilder<DailySummaryWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay.toMinutes(), TimeUnit.MINUTES)
            .build()
        workManager.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
