package com.jarvis.assistant.data.settings

import android.content.Context
import com.jarvis.assistant.core.SecureStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val backendUrl: String = "",
    val wakeWord: Boolean = false,
    val memoryEnabled: Boolean = true,
    val logConversations: Boolean = true,
    val collectNotifications: Boolean = false,
    val shareNotificationsWithAi: Boolean = false,
    val dailySummary: Boolean = false
)

class SettingsRepository(context: Context, private val secure: SecureStore) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _flow = MutableStateFlow(load())

    val flow: StateFlow<AppSettings> = _flow.asStateFlow()
    val current: AppSettings get() = _flow.value

    @Synchronized
    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_flow.value)
        prefs.edit()
            .putString("backend_url", next.backendUrl)
            .putBoolean("wake_word", next.wakeWord)
            .putBoolean("memory", next.memoryEnabled)
            .putBoolean("log_conversations", next.logConversations)
            .putBoolean("collect_notifications", next.collectNotifications)
            .putBoolean("share_notifications", next.shareNotificationsWithAi)
            .putBoolean("daily_summary", next.dailySummary)
            .apply()
        _flow.value = next
    }

    fun token(): String? = secure.get(TOKEN_KEY)
    fun setToken(value: String?) = secure.put(TOKEN_KEY, value)

    private fun load() = AppSettings(
        backendUrl = prefs.getString("backend_url", "") ?: "",
        wakeWord = prefs.getBoolean("wake_word", false),
        memoryEnabled = prefs.getBoolean("memory", true),
        logConversations = prefs.getBoolean("log_conversations", true),
        collectNotifications = prefs.getBoolean("collect_notifications", false),
        shareNotificationsWithAi = prefs.getBoolean("share_notifications", false),
        dailySummary = prefs.getBoolean("daily_summary", false)
    )

    private companion object {
        const val TOKEN_KEY = "backend_token"
    }
}
