package com.jarvis.assistant.core

import android.app.Application
import androidx.room.Room
import com.jarvis.assistant.automation.PhoneActionExecutor
import com.jarvis.assistant.automation.ReminderScheduler
import com.jarvis.assistant.data.ai.AiBackend
import com.jarvis.assistant.data.ai.ProxyAiBackend
import com.jarvis.assistant.data.memory.JarvisDatabase
import com.jarvis.assistant.data.memory.MemoryRepository
import com.jarvis.assistant.data.settings.SettingsRepository
import com.jarvis.assistant.domain.AssistantEngine
import com.jarvis.assistant.voice.BengaliTts
import com.jarvis.assistant.voice.SpeechListener
import com.jarvis.assistant.voice.VoiceConversation
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Manual dependency container; keeps wiring in one place without a DI framework. */
class AppContainer(app: Application) {
    val secureStore = SecureStore(app)
    val settings = SettingsRepository(app, secureStore)
    val db: JarvisDatabase = Room.databaseBuilder(app, JarvisDatabase::class.java, "jarvis.db").build()
    val memoryRepo = MemoryRepository(db)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()
    val backend: AiBackend = ProxyAiBackend(settings, http)

    val reminders = ReminderScheduler(app, db.reminderDao())
    private val executor = PhoneActionExecutor(app, reminders, memoryRepo, settings)
    val engine = AssistantEngine(app, settings, memoryRepo, backend, executor)

    val tts = BengaliTts(app)
    val listener = SpeechListener(app)
    val conversation = VoiceConversation(app, engine, tts, listener)
}
