package com.jarvis.assistant.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tracks whether the main activity is visible, so background work can pause or defer UI launches. */
object AppVisibility {
    private val _foreground = MutableStateFlow(false)
    val foreground: StateFlow<Boolean> = _foreground.asStateFlow()
    val inForeground: Boolean get() = _foreground.value

    fun set(visible: Boolean) {
        _foreground.value = visible
    }
}
