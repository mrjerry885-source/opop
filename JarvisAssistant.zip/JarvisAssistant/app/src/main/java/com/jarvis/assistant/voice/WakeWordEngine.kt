package com.jarvis.assistant.voice

import kotlinx.coroutines.delay
import kotlin.math.min

class WakeWordUnavailableException(message: String) : Exception(message)

/**
 * A wake word engine suspends until the wake phrase is heard, and is cancelled by cancelling the coroutine.
 * Swap the implementation (for example for a dedicated on-device keyword spotter) without touching the service.
 */
interface WakeWordEngine {
    suspend fun awaitWakeWord()
}

/**
 * Default engine: loops short offline-preferred recognitions and looks for "Hey JARVIS".
 * It needs no API key, but is heavier on battery than a dedicated keyword spotter and some devices
 * play a recognizer beep.
 */
class SpeechKeywordWakeWordEngine(private val listener: SpeechListener) : WakeWordEngine {
    override suspend fun awaitWakeWord() {
        var failures = 0
        while (true) {
            when (val result = listener.listenOnce(languageTag = "en-US", preferOffline = true)) {
                is ListenResult.Text -> {
                    if (WakePhrase.matches(result.value)) return
                    failures = 0
                }
                ListenResult.NoSpeech -> {
                    failures = 0
                    delay(RESTART_DELAY_MS)
                }
                ListenResult.PermissionDenied ->
                    throw WakeWordUnavailableException("Microphone permission missing")
                ListenResult.Unavailable ->
                    throw WakeWordUnavailableException("No speech recognition service")
                is ListenResult.Failure -> {
                    failures++
                    delay(min(MAX_BACKOFF_MS, BACKOFF_STEP_MS * failures))
                }
            }
        }
    }

    private companion object {
        const val RESTART_DELAY_MS = 300L
        const val BACKOFF_STEP_MS = 1_000L
        const val MAX_BACKOFF_MS = 30_000L
    }
}
