package com.jarvis.assistant.domain

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Extracts an optional <action>{...}</action> tag from an AI reply. */
object ActionParser {
    data class Parsed(val spokenText: String, val action: PhoneAction?)

    private val tag = Regex("<action>(.*?)</action>", RegexOption.DOT_MATCHES_ALL)

    fun parse(reply: String): Parsed {
        val spoken = reply.replace(tag, "").trim()
        val action = tag.find(reply)?.let { match ->
            runCatching { toAction(Json.parseToJsonElement(match.groupValues[1].trim()).jsonObject) }.getOrNull()
        }
        return Parsed(spoken, action)
    }

    private fun toAction(obj: JsonObject): PhoneAction? {
        fun str(key: String) = obj[key]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
        fun int(key: String) = obj[key]?.jsonPrimitive?.intOrNull
        return when (str("type")) {
            "flashlight" -> obj["on"]?.jsonPrimitive?.booleanOrNull?.let { PhoneAction.Flashlight(it) }
            "alarm" -> {
                val h = int("hour") ?: return null
                val m = int("minute") ?: 0
                if (h in 0..23 && m in 0..59) PhoneAction.Alarm(h, m) else null
            }
            "timer" -> int("seconds")?.takeIf { it in 1..86_400 }?.let { PhoneAction.Timer(it) }
            "dial" -> str("number")?.filter { it.isDigit() || it == '+' }?.takeIf { it.length >= 3 }
                ?.let { PhoneAction.Dial(it) }
            "open_app" -> str("name")?.let { PhoneAction.OpenApp(it) }
            "remember" -> str("text")?.let { PhoneAction.Remember(it) }
            "remind" -> {
                val text = str("text") ?: return null
                val minutes = int("minutes")?.takeIf { it in 1..10_080 } ?: return null
                PhoneAction.Remind(text, minutes)
            }
            "summarize_notifications" -> PhoneAction.SummarizeNotifications
            else -> null
        }
    }
}
