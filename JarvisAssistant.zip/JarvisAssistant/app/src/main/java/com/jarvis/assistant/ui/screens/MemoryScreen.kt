package com.jarvis.assistant.ui.screens

import android.text.format.DateUtils
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.R
import com.jarvis.assistant.ui.MainViewModel

@Composable
fun MemoryScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val flags = DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_MONTH

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (memories.isEmpty() && reminders.isEmpty()) {
            item { Text(stringResource(R.string.memory_empty)) }
        }
        if (reminders.isNotEmpty()) {
            item { Text(stringResource(R.string.memory_reminders), style = MaterialTheme.typography.titleMedium) }
            items(reminders, key = { "r${it.id}" }) { reminder ->
                EntryCard(
                    text = reminder.text,
                    meta = DateUtils.formatDateTime(context, reminder.triggerAt, flags),
                    deleteLabel = stringResource(R.string.delete),
                    onDelete = { viewModel.deleteReminder(reminder.id) }
                )
            }
        }
        if (memories.isNotEmpty()) {
            item { Text(stringResource(R.string.memory_notes), style = MaterialTheme.typography.titleMedium) }
            items(memories, key = { "m${it.id}" }) { memory ->
                EntryCard(
                    text = memory.text,
                    meta = DateUtils.formatDateTime(context, memory.createdAt, flags),
                    deleteLabel = stringResource(R.string.delete),
                    onDelete = { viewModel.deleteMemory(memory.id) }
                )
            }
        }
    }
}

@Composable
private fun EntryCard(text: String, meta: String, deleteLabel: String, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                Text(text, maxLines = 6)
                Text(meta, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = deleteLabel) }
        }
    }
}
